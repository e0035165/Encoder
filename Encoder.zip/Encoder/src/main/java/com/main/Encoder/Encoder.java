package com.main.Encoder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Encoder {
	public static char[] lister = new char[44];
	public static HashMap<Integer,Integer> twister = new HashMap<>();
	public static int Size;
	Encoder()
	{
		Integer count = 0;
		for(int i=0;i<26;i++)
		{
			lister[count] = (char)(i+65);
			Encoder.twister.put(i+65, count);
			count++;
		}
		
		for(int i=0;i<10;i++)
		{
			lister[count] = (char)(i+48);
			Encoder.twister.put(i+48, count);
			count++;
		}
		for(int i=0;i<=7;i++)
		{
			lister[count] = (char)(i+40);
			Encoder.twister.put(i+40, count);
			count++;
		}
		
		Size = Encoder.twister.size();
	}
	
	
	public char[] encodedMsg(char[] start, char offset)
	{
		char[] end = new char[start.length];
		int R = (int)offset;
		int index = Encoder.twister.get(R);
		int count = 0;
		Integer val = 0;
		while(count < start.length)
		{
			if(start[count] == ' ' || (int)start[count] == 13)
			{
				end[count] = ' ';
			} else {
				int valr = (int)start[count];
				//System.out.println("bbb:"+valr +"char:" +start[count]);
				val = Encoder.twister.get(valr);
				//System.out.println(val);
				end[count] = lister[((val - index + Size)%Size)];
			}
			++count;
		}
		return end;
	}
	
	
	
	

}
