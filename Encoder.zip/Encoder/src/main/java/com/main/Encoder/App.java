package com.main.Encoder;

import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        
        
        int loop = 0;
        String str = "";
    	Encoder test = new Encoder();
    	Scanner scatt = new Scanner(System.in);
        System.out.print("Number of strings: ");
        loop = scatt.nextInt();
        
        
        while(loop > 0) {
        	
        	System.out.print("Enter capital offset letter: ");
        	char b = scatt.next().charAt(0);
        	System.out.print("Enter String: ");
        	scatt = new Scanner(System.in).useDelimiter("\n");
        	str = scatt.next();
        	char[] start = str.toCharArray();
        	char[] ans = test.encodedMsg(start, b);
        	str = String.valueOf(ans);
        	System.out.println(str);
            loop--;
            
        }
        scatt.close();
        
    }
    
    
}
